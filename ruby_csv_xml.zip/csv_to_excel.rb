require 'spreadsheet'

class Csv_to_excel
	def generate_excel_file(headers, data) # Function creates an excel file & return excel object
		new_book = Spreadsheet::Workbook.new
		new_book.create_worksheet :name => 'Sheet Name'
		new_book.worksheet(0).insert_row(0, headers)	# Add headers in the excel file
		data.each_with_index do |row, data_index|
			single_record = row.split("|")
			new_book.worksheet(0).insert_row(data_index+1, single_record)	# Add new row in the excel file
		end
		new_book
	end
end

csv_to_excel = Csv_to_excel.new()

csv_files = ["/home/yching/Downloads/Csv1.csv", "/home/yching/Downloads/Csv2.csv"]	# Csv files path
csv_files.each_with_index do |csv_file, csv_index|
	doc = File.read(csv_file)
	file_data = doc.split("\r\n")
	headers = file_data[0].split("|")
	data = file_data[1..-1]
	new_book = csv_to_excel.generate_excel_file(headers, data)	# Calling excel generate function
	new_book.write("output#{csv_index+1}.xls")
end
