require 'nokogiri'

class Mergexml

  def merge_files(file1, file2)     # Function used to mrge xml files & return the merged file
    xml_file1 = Nokogiri::XML(File.open(file1))
    xml_file2 = Nokogiri::XML(File.open(file2))

    xml2_movies = xml_file2.search('movie')
    xml_file1.xpath("//movie")[-1].add_next_sibling(xml2_movies)

    merged_xml_file = xml_file1.to_xml

    File.open("merged_xml.xml", 'w') do |file|    # Writing merged data to new xml file
    	file << merged_xml_file        
    end
  end
end

merge_xml = Mergexml.new()
merge_xml.merge_files("output1.xml", "output2.xml") # Calling merged function with files names

