require 'builder'

class Csv_to_xml

	def movietitle_xml(headers, data)	# Function used to convert into xml	
		xml = Builder::XmlMarkup.new( :indent => 2 )
		xml.collection("shelf" => "New Arrivals") do |c|
			data.each_with_index do |record, index_no|
				single_record = record.split("|")
				c.movie("#{headers[0].downcase}" => single_record[0]) do |movie_record|	# making xml rows

					movie_record.tag!("#{headers[1].downcase}","#{single_record[1]}")
					movie_record.tag!("#{headers[2].downcase}","#{single_record[2]}") 
					movie_record.tag!("#{headers[3].downcase}","#{single_record[3]}") 
					movie_record.tag!("#{headers[4].downcase}","#{single_record[4]}") 
					movie_record.tag!("#{headers[5].downcase}","#{single_record[5]}") 
					movie_record.tag!("#{headers[6].downcase}","#{single_record[6]}")
				end
			end
		end
	end
end


csv_to_xml = Csv_to_xml.new()

csv_files = ["/home/yching/Downloads/Csv1.csv", "/home/yching/Downloads/Csv2.csv"]	# Csv file names needs to convert
csv_files.each_with_index do |csv_file, csv_index|
	doc = File.read(csv_file)
	file_data = doc.split("\r\n")
	headers = file_data[0].split("|")
	File.open("output#{csv_index+1}.xml", 'w') do |file|
	 file << csv_to_xml.movietitle_xml(headers, file_data[1..-1])	# Calling xml convertion function & write data to file
	end
end